const form = document.getElementById("loginForm");
const username = document.getElementById("username");
const password = document.getElementById("password");
const errorMsg = document.getElementById("errorMsg");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  if (username.value.trim() === "" || password.value.trim() === "") {
    errorMsg.textContent = "⚠ Please enter username and password!";
    errorMsg.style.color = "red";
    return;
  }

  if (username.value === "admin" && password.value === "1234") {
    errorMsg.style.color = "green";
    errorMsg.textContent = "✅ Login successful!";
    // Example redirect
    // window.location.href = "dashboard.html";
  } else {
    errorMsg.style.color = "red";
    errorMsg.textContent = "❌ Invalid credentials!";
  }
});