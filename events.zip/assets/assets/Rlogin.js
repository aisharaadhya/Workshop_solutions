const loginForm = document.getElementById("loginForm");
const msg = document.getElementById("msg");

loginForm.addEventListener("submit", (e) => {
  e.preventDefault(); // stop refresh

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  // ✅ Validation
  if (email === "" || password === "") {
    msg.textContent = "⚠ Please fill all fields!";
    msg.style.color = "red";
    return;
  }

  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!email.match(emailPattern)) {
    msg.textContent = "⚠ Please enter a valid email!";
    msg.style.color = "red";
    return;
  }

  if (password.length < 5) {
    msg.textContent = "⚠ Password must be at least 5 characters!";
    msg.style.color = "red";
    return;
  }

  // ✅ Success
  msg.textContent = "✅ Login successful!";
  msg.style.color = "green";

  // 🎉 Alert popup
  setTimeout(() => {
    alert("🎉 Successfully Logged In!");
  }, 300);
});