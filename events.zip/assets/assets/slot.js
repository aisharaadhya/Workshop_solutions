const SLOTS = [
  { id: "10-12", label: "10:00 – 12:00" },
  { id: "12-14", label: "12:30 – 14:30" },
  { id: "15-17", label: "15:00 – 17:00" },
  { id: "17-19", label: "17:30 – 19:30" },
  { id: "20-22", label: "20:00 – 22:00" }
];

const DOM = {
  form: document.getElementById("bookingForm"),
  name: document.getElementById("fullName"),
  phone: document.getElementById("phone"),
  email: document.getElementById("email"),
  guests: document.getElementById("guests"),
  date: document.getElementById("partyDate"),
  notes: document.getElementById("notes"),
  slotGrid: document.getElementById("slotGrid"),
  toast: document.getElementById("toast"),
  reset: document.getElementById("resetForm"),
  list: document.getElementById("bookingList"),
  refreshList: document.getElementById("refreshList"),
  clearDemoData: document.getElementById("clearDemoData")
};

let selectedSlotId = null;

/* Utils */
const storageKey = "birthday-bookings-v1";

function getAllBookings() {
  try {
    return JSON.parse(localStorage.getItem(storageKey)) || {};
  } catch {
    return {};
  }
}

function setAllBookings(data) {
  localStorage.setItem(storageKey, JSON.stringify(data));
}

function getBookingsByDate(dateStr) {
  const all = getAllBookings();
  return all[dateStr] || [];
}

function addBooking(dateStr, booking) {
  const all = getAllBookings();
  if (!all[dateStr]) all[dateStr] = [];
  all[dateStr].push(booking);
  setAllBookings(all);
}

function formatDateHuman(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  const opts = { weekday: "short", year: "numeric", month: "short", day: "numeric" };
  return d.toLocaleDateString(undefined, opts);
}

function showToast(msg, isError = false) {
  DOM.toast.textContent = msg;
  DOM.toast.classList.toggle("error", isError);
  DOM.toast.style.display = "block";
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => (DOM.toast.style.display = "none"), 3500);
}

function setMinDateToday() {
  const today = new Date();
  today.setHours(0,0,0,0);
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth() + 1).padStart(2, "0");
  const dd = String(today.getDate()).padStart(2, "0");
  DOM.date.min = ${yyyy}-${mm}-${dd};
}

/* Slot rendering */
function renderSlotsForDate(dateStr) {
  DOM.slotGrid.innerHTML = "";
  selectedSlotId = null;

  if (!dateStr) {
    DOM.slotGrid.innerHTML = <p class="muted">Pick a date to view slots.</p>;
    return;
  }

  const booked = new Set(getBookingsByDate(dateStr).map(b => b.slotId));

  SLOTS.forEach(slot => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "slot-btn";
    btn.setAttribute("role", "option");
    btn.setAttribute("aria-selected", "false");
    btn.dataset.slotId = slot.id;

    const label = document.createElement("span");
    label.textContent = slot.label;

    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = booked.has(slot.id) ? "Booked" : "Available";

    btn.append(label, badge);

    if (booked.has(slot.id)) {
      btn.disabled = true;
    }

    btn.addEventListener("click", () => {
      document
        .querySelectorAll(".slot-grid button[aria-selected='true']")
        .forEach(el => el.setAttribute("aria-selected", "false"));

      btn.setAttribute("aria-selected", "true");
      selectedSlotId = slot.id;
      clearFieldError("slot");
    });

    DOM.slotGrid.appendChild(btn);
  });
}

/* Validation helpers */
function setFieldError(fieldName, message) {
  const el = document.querySelector([data-error-for="${fieldName}"]);
  if (el) el.textContent = message || "";
}
function clearFieldError(fieldName) {
  setFieldError(fieldName, "");
}

function validateForm() {
  let ok = true;

  if (!DOM.name.value.trim()) {
    setFieldError("fullName", "Please enter your name.");
    ok = false;
  } else {
    clearFieldError("fullName");
  }

  const phoneVal = DOM.phone.value.trim();
  if (!/^[0-9]{10}$/.test(phoneVal)) {
    setFieldError("phone", "Enter a valid 10-digit phone number.");
    ok = false;
  } else {
    clearFieldError("phone");
  }

  if (DOM.email.value && !/^\S+@\S+\.\S+$/.test(DOM.email.value.trim())) {
    setFieldError("email", "Invalid email address.");
    ok = false;
  } else {
    clearFieldError("email");
  }

  const guests = parseInt(DOM.guests.value, 10);
  if (!guests || guests < 1) {
    setFieldError("guests", "Please enter number of guests.");
    ok = false;
  } else {
    clearFieldError("guests");
  }

  const date = DOM.date.value;
  if (!date) {
    setFieldError("partyDate", "Please select a party date.");
    ok = false;
  } else {
    clearFieldError("partyDate");
    // prevent past date selection (extra guard)
    const sel = new Date(date + "T00:00:00");
    const today = new Date();
    today.setHours(0,0,0,0);
    if (sel < today) {
      setFieldError("partyDate", "Date cannot be in the past.");
      ok = false;
    }
  }

  if (!selectedSlotId) {
    setFieldError("slot", "Pick one available time slot.");
    ok = false;
  } else {
    clearFieldError("slot");
  }

  return ok;
}

/* Booking list (preview) */
function renderBookingList(dateStr) {
  const bookings = getBookingsByDate(dateStr);
  DOM.list.innerHTML = "";

  if (!dateStr) {
    DOM.list.innerHTML = <p class="muted">Choose a date above to see bookings for that day.</p>;
    return;
  }
  if (!bookings.length) {
    DOM.list.innerHTML = <p class="muted">No bookings yet for ${formatDateHuman(dateStr)}.</p>;
    return;
  }

  bookings
    .sort((a,b)=> a.slotId.localeCompare(b.slotId))
    .forEach(b => {
      const item = document.createElement("div");
      item.className = "booking-item";
      item.innerHTML = `
        <div>
          <strong>${b.name}</strong>
          <div class="muted">Phone: ${b.phone}${b.email ? " • " + b.email : ""}</div>
        </div>
        <div>
          <span class="tag">${SLOTS.find(s=>s.id===b.slotId)?.label || b.slotId}</span>
          <span class="tag">${b.guests} guests</span>
          <span class="tag">ID: ${b.id}</span>
        </div>
      `;
      DOM.list.appendChild(item);
    });
}

/* Handlers */
DOM.date.addEventListener("change", () => {
  renderSlotsForDate(DOM.date.value);
  renderBookingList(DOM.date.value);
});

DOM.reset.addEventListener("click", () => {
  DOM.form.reset();
  selectedSlotId = null;
  document
    .querySelectorAll(".slot-grid button[aria-selected='true']")
    .forEach(el => el.setAttribute("aria-selected", "false"));
  clearFieldError("fullName");
  clearFieldError("phone");
  clearFieldError("email");
  clearFieldError("guests");
  clearFieldError("partyDate");
  clearFieldError("slot");
  showToast("Form cleared.");
});

DOM.refreshList.addEventListener("click", () => {
  renderBookingList(DOM.date.value);
  showToast("List refreshed.");
});

DOM.clearDemoData.addEventListener("click", () => {
  if (confirm("Clear all demo bookings saved in this browser?")) {
    localStorage.removeItem(storageKey);
    renderSlotsForDate(DOM.date.value);
    renderBookingList(DOM.date.value);
    showToast("Demo data cleared.");
  }
});

DOM.form.addEventListener("submit", (e) => {
  e.preventDefault();
  if (!validateForm()) {
    showToast("Please fix the highlighted fields.", true);
    return;
  }

  const dateStr = DOM.date.value;
  const existing = getBookingsByDate(dateStr);

  // Reject if slot already booked
  if (existing.some(b => b.slotId === selectedSlotId)) {
    showToast("Sorry, that slot just got booked. Pick another.", true);
    renderSlotsForDate(dateStr);
    return;
  }

  const bookingId = Math.random().toString(36).slice(2, 8).toUpperCase();
  const booking = {
    id: bookingId,
    name: DOM.name.value.trim(),
    phone: DOM.phone.value.trim(),
    email: DOM.email.value.trim(),
    guests: parseInt(DOM.guests.value, 10),
    date: dateStr,
    slotId: selectedSlotId,
    notes: DOM.notes.value.trim(),
    createdAt: new Date().toISOString()
  };

  addBooking(dateStr, booking);
  renderSlotsForDate(dateStr);
  renderBookingList(dateStr);

  showToast(Booked! Your ID is ${bookingId}.);
  DOM.form.reset();
  selectedSlotId = null;
});

/* Init */
setMinDateToday();
// Pre-select today to encourage interaction
DOM.date.value = DOM.date.min;
renderSlotsForDate(DOM.date.value);
renderBookingList(DOM.date.value);